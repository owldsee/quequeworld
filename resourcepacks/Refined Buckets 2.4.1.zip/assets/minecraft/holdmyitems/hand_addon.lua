global.offhand = 0.0;
global.pitchAngle = 0.0;
global.pitchAngleO = 0.0;
global.yawAngle = 0.0;
global.yawAngleO = 0.0;
global.foodCount = 0.0;
global.foodCountSec = 0.0;
global.drinkCount = 0.0;

local l = (context.bl and 1) or -1
local player = context.player
local item = context.item
local matrices = context.matrices
local mainHand = context.mainHand
local offhand = offhand

local ptAngle = (mainHand and pitchAngle) or pitchAngleO
local ywAngle = (mainHand and yawAngle) or yawAngleO

local buckets = {
    "minecraft:bucket",
    "minecraft:water_bucket",
    "minecraft:lava_bucket",
    "minecraft:powder_snow_bucket",
    "minecraft:cod_bucket",
    "minecraft:salmon_bucket",
    "minecraft:tropical_fish_bucket",
    "minecraft:tadpole_bucket"
}

for _, id in ipairs(buckets) do
    if I:isOf(item, Items:get(id)) then
        M:moveY(matrices, 0.4)
        M:moveZ(matrices, -0.05)
        return
    end
end

local drinking = P:isUsingItem(player)

if I:isOf(item, Items:get("minecraft:milk_bucket")) then
    if drinking and mainHand and drinkCount > 0 then
        offhand = -0.1
    end

    if not drinking then
        M:moveY(matrices, 0.4)
        M:moveZ(matrices, -0.05)
    end
end
if I:isOf(P:getMainItem(player), Items:get("minecraft:milk_bucket")) 
    and drinking
    and not mainHand
    and I:isEmpty(item)
then
    local easedFoodCount = foodCount * foodCount
    local dc = M:clamp((drinkCount + 0.06) * 5, 0, 1)
    dc = dc * dc
    M:moveZ(matrices, -0.55 * easedFoodCount * dc)
    M:moveX(matrices, 0.3 * l * easedFoodCount * dc)
    M:moveY(matrices, -0.5 * easedFoodCount * dc)
    M:rotateX(matrices, 50 * easedFoodCount * dc)
    M:rotateX(matrices, 20 * drinkCount * dc)
    M:rotateX(matrices, 2 * M:sin(foodCountSec * 6) * drinkCount * dc)
    M:rotateY(matrices, l * 60 * easedFoodCount * dc, 0.3 * l, -0.4, 0)
    M:rotateX(matrices, 25 * M:sin(easedFoodCount * 3.14) * dc, 0.3 * l, -0.4, 0)
end